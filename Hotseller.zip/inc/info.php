<?php 
date_default_timezone_set('America/New_York');
echo phpinfo();
?>